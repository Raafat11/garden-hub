<?php
$pageTitle = 'Admin Dashboard - Garden Hub';
require_once '../../core/Security.php';
require_once '../../config/Database.php';
require_once '../../classes/Admin.php';

// لازم Admin
Security::requireRole(['admin']);

$admin = new Admin($_SESSION['userId']);
$db = Database::getInstance()->getConnection();

// Get Stats
$stats = [
    'users' => $db->query("SELECT COUNT(*) FROM users")->fetchColumn(),
    'plots' => $db->query("SELECT COUNT(*) FROM plots")->fetchColumn(),
    'active_plots' => $db->query("SELECT COUNT(*) FROM plots WHERE status = 'rented'")->fetchColumn(),
    'tools' => $db->query("SELECT COUNT(*) FROM tools")->fetchColumn(),
    'pending_leases' => $db->query("SELECT COUNT(*) FROM leases WHERE status = 'pending'")->fetchColumn(),
    'incidents' => $db->query("SELECT COUNT(*) FROM incidents WHERE status = 'open'")->fetchColumn()
];

// Get recent audit logs
$auditLogs = $admin->viewAuditTrail(10);

include '../../templates/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <?php include '../../templates/sidebar.php'; ?>
        
        <div class="col-md-10 p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 style="color:#1D3557;">
                    <i class="bi bi-speedometer2"></i> Admin Dashboard
                </h2>
                <span class="text-muted">Welcome, <?= Security::escape($_SESSION['name']) ?></span>
            </div>
            
            <!-- Stats Cards -->
            <div class="row g-3 mb-4">
                <div class="col-md-2">
                    <div class="card card-glass text-center">
                        <div class="card-body">
                            <i class="bi bi-people display-6" style="color:#2D6A4F;"></i>
                            <h3 class="mt-2"><?= $stats['users'] ?></h3>
                            <p class="text-muted mb-0">Total Users</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-2">
                    <div class="card card-glass text-center">
                        <div class="card-body">
                            <i class="bi bi-grid-3x3 display-6" style="color:#2D6A4F;"></i>
                            <h3 class="mt-2"><?= $stats['plots'] ?></h3>
                            <p class="text-muted mb-0">Total Plots</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-2">
                    <div class="card card-glass text-center">
                        <div class="card-body">
                            <i class="bi bi-check-circle display-6" style="color:#2D6A4F;"></i>
                            <h3 class="mt-2"><?= $stats['active_plots'] ?></h3>
                            <p class="text-muted mb-0">Active Plots</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-2">
                    <div class="card card-glass text-center">
                        <div class="card-body">
                            <i class="bi bi-tools display-6" style="color:#2D6A4F;"></i>
                            <h3 class="mt-2"><?= $stats['tools'] ?></h3>
                            <p class="text-muted mb-0">Tools</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-2">
                    <div class="card card-glass text-center">
                        <div class="card-body">
                            <i class="bi bi-file-earmark-text display-6" style="color:#FFB703;"></i>
                            <h3 class="mt-2"><?= $stats['pending_leases'] ?></h3>
                            <p class="text-muted mb-0">Pending Leases</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-2">
                    <div class="card card-glass text-center">
                        <div class="card-body">
                            <i class="bi bi-exclamation-triangle display-6" style="color:#D62828;"></i>
                            <h3 class="mt-2"><?= $stats['incidents'] ?></h3>
                            <p class="text-muted mb-0">Open Incidents</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Quick Actions + Recent Activity -->
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="card card-glass">
                        <div class="card-header" style="background:var(--primary); color:white;">
                            <h5 class="mb-0"><i class="bi bi-lightning"></i> Quick Actions</h5>
                        </div>
                        <div class="card-body">
                            <div class="d-grid gap-2">
                                <a href="rbac.php" class="btn btn-outline-success">
                                    <i class="bi bi-shield-lock"></i> Manage RBAC
                                </a>
                                <a href="broadcasts.php" class="btn btn-outline-warning">
                                    <i class="bi bi-megaphone"></i> Emergency Broadcast
                                </a>
                                <a href="lease-approval.php" class="btn btn-outline-info">
                                    <i class="bi bi-file-check"></i> Approve Leases
                                </a>
                                <a href="audit.php" class="btn btn-outline-secondary">
                                    <i class="bi bi-clipboard-data"></i> View Audit Trail
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-8">
                    <div class="card card-glass">
                        <div class="card-header" style="background:var(--primary); color:white;">
                            <h5 class="mb-0"><i class="bi bi-clock-history"></i> Recent System Activity</h5>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead>
                                        <tr>
                                            <th>User</th>
                                            <th>Action</th>
                                            <th>Entity</th>
                                            <th>Time</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($auditLogs as $log): ?>
                                        <tr>
                                            <td><?= Security::escape($log['name']) ?></td>
                                            <td><span class="badge bg-secondary"><?= Security::escape($log['action']) ?></span></td>
                                            <td><?= Security::escape($log['entityType'] ?? 'N/A') ?></td>
                                            <td><small><?= date('M d, H:i', strtotime($log['timestamp'])) ?></small></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../../templates/footer.php'; ?>