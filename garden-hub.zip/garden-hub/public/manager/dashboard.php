<?php
$pageTitle = 'Manager Dashboard - Garden Hub';
require_once '../../core/Security.php';
require_once '../../classes/GardenManager.php';

Security::requireRole(['garden_manager']);

$manager = new GardenManager($_SESSION['userId']);
$db = Database::getInstance()->getConnection();

// Get stats
$stats = [
    'total_plots' => $db->query("SELECT COUNT(*) FROM plots")->fetchColumn(),
    'active_plots' => $db->query("SELECT COUNT(*) FROM plots WHERE status = 'rented'")->fetchColumn(),
    'open_incidents' => $db->query("SELECT COUNT(*) FROM incidents WHERE status = 'open'")->fetchColumn(),
    'pest_alerts' => $db->query("SELECT COUNT(*) FROM alerts WHERE type = 'pest' AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)")->fetchColumn(),
    'pending_quality' => $db->query("SELECT COUNT(*) FROM products WHERE qualityVerified = 0")->fetchColumn(),
    'maintenance_due' => $db->query("SELECT COUNT(*) FROM tools WHERE usageHours >= 100 AND status != 'maintenance'")->fetchColumn()
];

// Get recent incidents
$incidents = $db->query("SELECT i.*, u.name as reporter_name FROM incidents i 
                         LEFT JOIN users u ON i.reportedBy = u.userId 
                         WHERE i.status = 'open' 
                         ORDER BY FIELD(i.severity, 'critical', 'high', 'medium', 'low'), i.date DESC 
                         LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);

include '../../templates/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <?php include '../../templates/sidebar.php'; ?>
        
        <div class="col-md-10 p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 style="color:#1D3557;">
                    <i class="bi bi-speedometer2"></i> Garden Manager Dashboard
                </h2>
                <span class="text-muted">Welcome, <?= Security::escape($_SESSION['name']) ?></span>
            </div>
            
            <!-- Stats Cards -->
            <div class="row g-3 mb-4">
                <div class="col-md-2">
                    <div class="card card-glass text-center">
                        <div class="card-body">
                            <i class="bi bi-grid-3x3 display-6" style="color:#2D6A4F;"></i>
                            <h3 class="mt-2"><?= $stats['total_plots'] ?></h3>
                            <p class="text-muted mb-0">Total Plots</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-2">
                    <div class="card card-glass text-center">
                        <div class="card-body">
                            <i class="bi bi-check-circle display-6" style="color:#2D6A4F;"></i>
                            <h3 class="mt-2"><?= $stats['active_plots'] ?></h3>
                            <p class="text-muted mb-0">Active Plots</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-2">
                    <div class="card card-glass text-center">
                        <div class="card-body">
                            <i class="bi bi-exclamation-triangle display-6" style="color:#D62828;"></i>
                            <h3 class="mt-2"><?= $stats['open_incidents'] ?></h3>
                            <p class="text-muted mb-0">Incidents</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-2">
                    <div class="card card-glass text-center">
                        <div class="card-body">
                            <i class="bi bi-bug display-6" style="color:#FFB703;"></i>
                            <h3 class="mt-2"><?= $stats['pest_alerts'] ?></h3>
                            <p class="text-muted mb-0">Pest Alerts</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-2">
                    <div class="card card-glass text-center">
                        <div class="card-body">
                            <i class="bi bi-award display-6" style="color:#FFB703;"></i>
                            <h3 class="mt-2"><?= $stats['pending_quality'] ?></h3>
                            <p class="text-muted mb-0">Quality Check</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-2">
                    <div class="card card-glass text-center">
                        <div class="card-body">
                            <i class="bi bi-wrench display-6" style="color:#D62828;"></i>
                            <h3 class="mt-2"><?= $stats['maintenance_due'] ?></h3>
                            <p class="text-muted mb-0">Maintenance</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Quick Actions + Recent Incidents -->
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="card card-glass">
                        <div class="card-header" style="background:var(--primary); color:white;">
                            <h5 class="mb-0"><i class="bi bi-lightning"></i> Quick Actions</h5>
                        </div>
                        <div class="card-body">
                            <div class="d-grid gap-2">
                                <a href="land-compliance.php" class="btn btn-outline-success">
                                    <i class="bi bi-clipboard-check"></i> Land Compliance Report
                                </a>
                                <a href="incidents.php" class="btn btn-outline-danger">
                                    <i class="bi bi-exclamation-circle"></i> Incident Reporting
                                </a>
                                <a href="pest-alerts.php" class="btn btn-outline-warning">
                                    <i class="bi bi-bug"></i> Pest/Disease Alert
                                </a>
                                <a href="seed-validation.php" class="btn btn-outline-info">
                                    <i class="bi bi-flower1"></i> Seed Validation
                                </a>
                                <a href="quality.php" class="btn btn-outline-primary">
                                    <i class="bi bi-award"></i> Quality Verification
                                </a>
                                <a href="plot-status.php" class="btn btn-outline-secondary">
                                    <i class="bi bi-house-gear"></i> Update Plot Status
                                </a>
                                <a href="lineage.php" class="btn btn-outline-dark">
                                    <i class="bi bi-diagram-3"></i> Genetic Lineage
                                </a>
                                <a href="maintenance.php" class="btn btn-outline-danger">
                                    <i class="bi bi-tools"></i> Usage Maintenance
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-8">
                    <div class="card card-glass">
                        <div class="card-header" style="background:var(--primary); color:white;">
                            <h5 class="mb-0"><i class="bi bi-exclamation-triangle"></i> Critical Incidents</h5>
                        </div>
                        <div class="card-body p-0">
                            <?php if(empty($incidents)): ?>
                                <div class="text-center p-4 text-muted">
                                    <i class="bi bi-check-circle display-1"></i>
                                    <p class="mt-3">No open incidents. All clear!</p>
                                </div>
                            <?php else: ?>
                                <div class="list-group list-group-flush">
                                    <?php foreach($incidents as $incident): ?>
                                    <div class="list-group-item">
                                        <div class="d-flex justify-content-between">
                                            <div>
                                                <h6 class="mb-1"><?= Security::escape($incident['type']) ?></h6>
                                                <p class="mb-1 text-muted"><?= Security::escape($incident['description']) ?></p>
                                                <small class="text-muted">
                                                    Reported by: <?= Security::escape($incident['reporter_name'] ?? 'Unknown') ?> | 
                                                    <?= date('M d, H:i', strtotime($incident['date'])) ?>
                                                </small>
                                            </div>
                                            <span class="badge bg-<?= $incident['severity'] === 'critical' ? 'danger' : ($incident['severity'] === 'high' ? 'warning' : 'info') ?>">
                                                <?= ucfirst($incident['severity']) ?>
                                            </span>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../../templates/footer.php'; ?>