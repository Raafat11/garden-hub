<?php
$pageTitle = 'Plot Owner Dashboard - Garden Hub';
require_once '../../core/Security.php';
require_once '../../classes/PlotOwner.php';

Security::requireRole(['plot_owner']);

$owner = new PlotOwner($_SESSION['userId']);
$db = Database::getInstance()->getConnection();

// Get owner's active lease
$lease = $db->prepare("SELECT l.*, p.plotId, p.area, p.soilType FROM leases l 
                       JOIN plots p ON l.plotId = p.plotId 
                       WHERE l.userId = ? AND l.status = 'active' LIMIT 1");
$lease->execute([$_SESSION['userId']]);
$activeLease = $lease->fetch(PDO::FETCH_ASSOC);

// Get stats
$stats = [
    'irrigation_status' => 'off',
    'active_crops' => 0,
    'inventory_items' => 0,
    'flash_trades' => 0
];

if($activeLease) {
    // Check irrigation status
    $irrigation = $db->prepare("SELECT status FROM irrigation_systems WHERE plotId = ? LIMIT 1");
    $irrigation->execute([$activeLease['plotId']]);
    $stats['irrigation_status'] = $irrigation->fetchColumn() ?: 'off';
    
    $stats['active_crops'] = $db->query("SELECT COUNT(*) FROM crop_records 
                                         WHERE plotId = {$activeLease['plotId']} AND status = 'active'")->fetchColumn();
}

$stats['inventory_items'] = $db->query("SELECT COUNT(*) FROM consumables WHERE userId = {$_SESSION['userId']}")->fetchColumn();
$stats['flash_trades'] = $db->query("SELECT COUNT(*) FROM flash_trades WHERE sellerId = {$_SESSION['userId']} AND status = 'active'")->fetchColumn();

include '../../templates/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <?php include '../../templates/sidebar.php'; ?>
        
        <div class="col-md-10 p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 style="color:#1D3557;">
                    <i class="bi bi-house-door"></i> Plot Owner Dashboard
                </h2>
                <span class="text-muted">Welcome, <?= Security::escape($_SESSION['name']) ?></span>
            </div>
            
            <?php if($activeLease): ?>
            <!-- Active Plot Card -->
            <div class="card card-glass mb-4" style="background:linear-gradient(135deg, #2D6A4F 0%, #1D3557 100%); color:white;">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h4><i class="bi bi-geo-alt"></i> Your Active Plot: #<?= $activeLease['plotId'] ?></h4>
                            <p class="mb-1"><strong>Area:</strong> <?= $activeLease['area'] ?> m² | <strong>Soil:</strong> <?= Security::escape($activeLease['soilType']) ?></p>
                            <p class="mb-0"><strong>Lease Ends:</strong> <?= date('M d, Y', strtotime($activeLease['endDate'])) ?></p>
                        </div>
                        <div class="col-md-4 text-end">
                            <h3>$<?= number_format($activeLease['rentAmount'], 2) ?>/month</h3>
                            <a href="rent-plot.php" class="btn btn-light btn-sm">Manage Lease</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php else: ?>
            <div class="alert alert-warning">
                <i class="bi bi-exclamation-triangle"></i> You don't have an active plot lease. 
                <a href="rent-plot.php" class="alert-link">Rent a plot now</a>
            </div>
            <?php endif; ?>
            
            <!-- Stats Cards -->
            <div class="row g-3 mb-4">
                <div class="col-md-3">
                    <div class="card card-glass text-center">
                        <div class="card-body">
                            <i class="bi bi-droplet display-6" style="color:<?= $stats['irrigation_status'] === 'on' ? '#2D6A4F' : '#999' ?>;"></i>
                            <h3 class="mt-2"><?= ucfirst($stats['irrigation_status']) ?></h3>
                            <p class="text-muted mb-0">Irrigation</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="card card-glass text-center">
                        <div class="card-body">
                            <i class="bi bi-flower1 display-6" style="color:#2D6A4F;"></i>
                            <h3 class="mt-2"><?= $stats['active_crops'] ?></h3>
                            <p class="text-muted mb-0">Active Crops</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="card card-glass text-center">
                        <div class="card-body">
                            <i class="bi bi-box-seam display-6" style="color:#FFB703;"></i>
                            <h3 class="mt-2"><?= $stats['inventory_items'] ?></h3>
                            <p class="text-muted mb-0">Inventory Items</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="card card-glass text-center">
                        <div class="card-body">
                            <i class="bi bi-lightning display-6" style="color:#D62828;"></i>
                            <h3 class="mt-2"><?= $stats['flash_trades'] ?></h3>
                            <p class="text-muted mb-0">Flash Trades</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Quick Actions -->
            <div class="card card-glass">
                <div class="card-header" style="background:var(--primary); color:white;">
                    <h5 class="mb-0"><i class="bi bi-lightning"></i> Quick Actions</h5>
                </div>
                <div class="card-body">
                    <div class="row g-2">
                        <div class="col-md-3">
                            <a href="irrigation.php" class="btn btn-outline-info w-100">
                                <i class="bi bi-droplet"></i> Irrigation
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="crop-data.php" class="btn btn-outline-success w-100">
                                <i class="bi bi-graph-up"></i> Crop Data
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="flash-trade.php" class="btn btn-outline-danger w-100">
                                <i class="bi bi-lightning"></i> Flash Trade
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="inventory.php" class="btn btn-outline-warning w-100">
                                <i class="bi bi-box-seam"></i> Inventory
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../../templates/footer.php'; ?>