<?php
$pageTitle = 'Volunteer Dashboard - Garden Hub';
require_once '../../core/Security.php';
require_once '../../classes/Volunteer.php';

Security::requireRole(['volunteer']);

$volunteer = new Volunteer($_SESSION['userId']);
$db = Database::getInstance()->getConnection();

// Get stats
$stats = [
    'total_points' => $volunteer->points,
    'completed_tasks' => 0,
    'upcoming_shifts' => 0,
    'mentorships' => 0
];

$stats['completed_tasks'] = $db->query("SELECT COUNT(*) FROM communal_tasks 
                                        WHERE assignedTo = {$_SESSION['userId']} AND status = 'completed'")->fetchColumn();

$stats['upcoming_shifts'] = $db->query("SELECT COUNT(*) FROM shifts 
                                        WHERE volunteerId = {$_SESSION['userId']} AND status = 'approved' AND startTime > NOW()")->fetchColumn();

$stats['mentorships'] = $db->query("SELECT COUNT(*) FROM mentorships 
                                    WHERE mentorId = {$_SESSION['userId']} OR menteeId = {$_SESSION['userId']}")->fetchColumn();

include '../../templates/header.php';
?>

<div class="container-fluid">
    <div class="row">
        <?php include '../../templates/sidebar.php'; ?>
        
        <div class="col-md-10 p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 style="color:#1D3557;">
                    <i class="bi bi-heart"></i> Volunteer Dashboard
                </h2>
                <span class="text-muted">Welcome, <?= Security::escape($_SESSION['name']) ?></span>
            </div>
            
            <!-- Points Card -->
            <div class="card card-glass mb-4" style="background:linear-gradient(135deg, #FFB703 0%, #D62828 100%); color:white;">
                <div class="card-body text-center">
                    <i class="bi bi-star-fill display-1"></i>
                    <h2 class="mt-2"><?= number_format($stats['total_points']) ?> Points</h2>
                    <p class="mb-0">Your Contribution Score</p>
                </div>
            </div>
            
            <!-- Stats Cards -->
            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <div class="card card-glass text-center">
                        <div class="card-body">
                            <i class="bi bi-check-circle display-6" style="color:#2D6A4F;"></i>
                            <h3 class="mt-2"><?= $stats['completed_tasks'] ?></h3>
                            <p class="text-muted mb-0">Completed Tasks</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="card card-glass text-center">
                        <div class="card-body">
                            <i class="bi bi-calendar-check display-6" style="color:#2D6A4F;"></i>
                            <h3 class="mt-2"><?= $stats['upcoming_shifts'] ?></h3>
                            <p class="text-muted mb-0">Upcoming Shifts</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="card card-glass text-center">
                        <div class="card-body">
                            <i class="bi bi-people display-6" style="color:#FFB703;"></i>
                            <h3 class="mt-2"><?= $stats['mentorships'] ?></h3>
                            <p class="text-muted mb-0">Mentorships</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Quick Actions -->
            <div class="card card-glass">
                <div class="card-header" style="background:var(--primary); color:white;">
                    <h5 class="mb-0"><i class="bi bi-lightning"></i> Quick Actions</h5>
                </div>
                <div class="card-body">
                    <div class="row g-2">
                        <div class="col-md-3">
                            <a href="tasks.php" class="btn btn-outline-success w-100">
                                <i class="bi bi-list-task"></i> View Tasks
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="join-shift.php" class="btn btn-outline-info w-100">
                                <i class="bi bi-calendar-plus"></i> Join Shift
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="mentorship.php" class="btn btn-outline-primary w-100">
                                <i class="bi bi-people"></i> Mentorship
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="points.php" class="btn btn-outline-warning w-100">
                                <i class="bi bi-star"></i> View Points
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../../templates/footer.php'; ?>